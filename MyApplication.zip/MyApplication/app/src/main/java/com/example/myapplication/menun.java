package com.example.myapplication;

//import android.R;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class menun extends AppCompatActivity {
    TextView t1,t2,t3;
    ImageView i1;
    Button b1;
    WebView w1;
    Integer pos;
    Integer img[]={R.drawable.ch, R.drawable.bee,R.drawable.mu,R.drawable.s6,R.drawable.f1,R.drawable.fm,R.drawable.cc,R.drawable.br,R.drawable.bc,R.drawable.mc};
    String d[] ={"\n" +
            "Ingredients\n" +
            "\n" +
            "    1 (1¾-pound/800-gram) chicken, skinned and cut into 12 pieces\n" +
            "    ¼ cup (50 ml) vegetable oil\n" +
            "    1-inch (2½-cm) cinnamon stick\n" +
            "    4 or 5 cloves\n" +
            "    4 or 5 green cardamom pods\n" +
            "    4 medium red onions, grated\n" +
            "    1 tablespoon fresh ginger paste\n" +
            "    1 tablespoon fresh garlic paste\n" +
            "    ½ teaspoon ground turmeric\n" +
            "    1½ tablespoons ground coriander\n" +
            "    1½ teaspoons ground roasted cumin (see Notes)\n" +
            "    1 teaspoon red chile powder\n" +
            "    4 medium tomatoes, puréed\n" +
            "    1½ teaspoons table salt\n" +
            "    1 teaspoon garam masala\n" +
            "    1 tablespoon chopped fresh cilantro\n" +
            "\n HOW TO MAKE IT \n" +
            "\n" +
            "    Trim the excess fat from the chicken and put the pieces in a large bowl.\n" +
            "\n" +
            "    Place a medium nonstick saucepan over medium heat and add the oil. When small bubbles appear at the bottom of the pan, add the cinnamon, cloves, and cardamom, and sauté for 1 minute. When the spices change color and are fragrant, add the onions and sauté for 3 to 4 minutes or until golden brown. Add the ginger paste and garlic paste, and sauté for 2 to 3 minutes, stirring continuously.\n" +
            "\n" +
            "    Add the turmeric, coriander, cumin, and chile powder. Stir well.\n" +
            "\n" +
            "    Add the tomatoes and sauté for 3 to 4 minutes, stirring continuously. Cook for 7 to 8 minutes or until the oil comes to the top.\n" +
            "\n" +
            "    Add the chicken and salt, and stir. Increase the heat to high and sauté for 5 minutes or until the chicken pieces are well coated with the sauce. Add 1½ cups (300 ml) water and bring to a boil. Lower the heat to low, cover, and cook for 10 minutes or until the chicken is cooked through.\n" +
            "\n" +
            "    Transfer to a serving bowl. Sprinkle with the garam masala and garnish with the cilantro. Serve hot.\n","Ingredients\n" +
            "\n" +
            "        2 pounds well-trimmed boneless beef stew meat, cut into 1-inch pieces\n" +
            "        3 tablespoons vegetable oil\n" +
            "        2 large onions, sliced\n" +
            "        6 whole cloves\n" +
            "        2 large garlic cloves, chopped\n" +
            "        2 cinnamon sticks\n" +
            "        1 bay leaf\n" +
            "        1/4 teaspoon dried crushed red pepper\n" +
            "        1 1/2 cups whole milk\n" +
            "        3 large tomatoes, quartered\n" +
            "        3 tablespoons Major Grey chutney\n" +
            "        3 tablespoons fresh lemon juice\n" +
            "        2 tablespoons minced peeled fresh ginger\n" +
            "        1 1/2 tablespoons curry powder\n" +
            "        1/2 teaspoon salt\n" +
            "        Hot cooked rice HOW TO MAKE IT          Sprinkle beef with salt and pepper. Heat 2 tablespoons oil in heavy large pot over high heat. Working in batches, add beef to pot and brown on all sides, about 7 minutes per batch. Using slotted spoon, transfer to plate.\n" +
            "        Heat remaining 1 tablespoon oil in same pot over medium-high heat. Add onions; sauté until tender and brown, about 7 minutes. Return beef to pot. Add cloves, garlic, cinnamon sticks, bay leaf and dried red pepper to pot; stir 1 minute. Stir in milk, tomatoes, chutney, lemon juice, ginger, curry powder and 1/2 teaspoon salt and bring to boil. Reduce heat, cover and simmer until beef is tender, stirring occasionally, about 2 hours.\n" +
            "        Uncover; increase heat to medium. Boil stew until juices are slightly thickened, about 10 minutes. Serve over rice. ","INGREDIENTS     1 kilograms mutton\n" +
            "    3 tablespoon garlic\n" +
            "    3 teaspoon cumin powder\n" +
            "    4 pinches salt\n" +
            "    1 teaspoon garam masala powder\n" +
            "    1/4 cup ghee\n" +
            "    2 bay leaf\n" +
            "    2 black cardamom\n" +
            "\n" +
            "    5 cup onion\n" +
            "    3 teaspoon ginger\n" +
            "    3 teaspoon coriander powder\n" +
            "    3 teaspoon white pepper powder\n" +
            "    1/2 cup mustard oil\n" +
            "    2 inches cinnamon\n" +
            "    4 clove\n" +
            "    2 green cardamom\n" +
            "\n" +
            "For Marination\n" +
            "\n" +
            "    1 teaspoon ginger paste\n" +
            "    4 teaspoon yoghurt (curd)\n" +
            "    2 teaspoon mustard oil\n" +
            "\n" +
            "    1 teaspoon garlic paste\n" +
            "    1 teaspoon salt How to make Mutton Curry\n" +
            "\n" +
            "    Step-1\n" +
            "    Step 1\n" +
            "\n" +
            "    Wash the mutton pieces (chopped into cubes) in running water. Keep aside to drain. When the water has almost dried, add the marinade ingredients. Mix well using your hands, rubbing the spices into the meat. Marinate for 1-2 hours.\n" +
            "    Step-2\n" +
            "    Step 2\n" +
            "\n" +
            "    Now take a heavy-bottomed pan and heat. One with a tight lid is preferred. Add oil and ghee. When smoke starts coming out of it, add the whole spices. Add a pinch of sugar. It gives an amazing colour to the mutton.\n" +
            "    step2 (1)\n" +
            "    Step 3\n" +
            "\n" +
            "    Add the chopped onions and cook on low flame for 10 minutes. At this point, you can add the salt. This increases the cooking process of onion.\n" +
            "    onions\n" +
            "    Step 4\n" +
            "\n" +
            "    When the onions turn translucent, reduce the heat and wait for them to turn pink. Add turmeric and mix well. You can add turmeric at a later stage also, but adding it in the beginning of the recipe helps you get rid of that raw smell of the spice.\n" +
            "    step3 (1)\n" +
            "    Step 5\n" +
            "\n" +
            "    Now add the marinated mutton, ginger garlic paste and cook on high flame for 5-7 minutes, stirring continuously.\n" +
            "    step4\n" +
            "    Step 6\n" +
            "\n" +
            "    Cover the lid of the vessel, lower the flame and allow it to simmer. When the mutton is almost done, add coriander, cumin, black pepper and mix well.\n" +
            "    step5\n" +
            "    Step 7\n" +
            "\n" +
            "    Cook uncovered till oil starts separating from the meat. Add a cup of water, garam masala powder and cook uncovered till oil floats on top. Transfer the mutton curry into a bowl, adjust seasoning, garnish with ginger juliennes, coriander leaves and serve hot with steamed rice or chapatti.","Ingredients:\n" +
            "\n" +
            "    400 gms boneless chicken\n" +
            "    1 egg white\n" +
            "    2 tbsp corn flour\n" +
            "    1 tbsp rice flour\n" +
            "    ½ tsp cumin seeds\n" +
            "    1 tsp Dabur Hommade Garlic Paste\n" +
            "    ½ tsp white pepper powder\n" +
            "    2 green chillies\n" +
            "    3-4 curry leaves\n" +
            "    Oil for frying\n" +
            "    Spring onion for garnish\n HOW TO MAKE IT Step 1:\n" +
            "\n" +
            "    Wash the chicken properly under running tap water\n" +
            "    Pat dry and keep aside\n" +
            "    To prepare the marination for the chicken, mix red chillies, turmeric, ginger garlic paste, lemon juice, black pepper powder, salt and yogurt together\n" +
            "    Use the mix to coat the chicken with it and keep it aside for a minimum of 45 minutes to an hour. You can also refrigerate it overnight if you wish to as it will yield tender and juicy chicken\n" +
            "\n" +
            "Step 2:\n" +
            "\n" +
            "    Time to prepare the seasoning for the chicken that has been resting for a while\n" +
            "    Add red chillies, yogurt, sugar, garlic paste and salt with 2 tbsp of water and keep aside\n" +
            "    Now take the marinated chicken out from the fridge and sprinkle corn and rice flour over it\n" +
            "    Now add egg white to the chicken and mix well or till all the ingredients have come together \n" +
            "\n" +
            "Step 3:\n" +
            "\n" +
            "    Heat oil in a pan\n" +
            "    Add chicken pieces to the oil and fry them till they turn golden and crisp\n" +
            "    Once fried, take the chicken pieces out on a kitchen towel and keep them aside for later use\n Step 4:\n" +
            "\n" +
            "    Heat oil in a pan\n" +
            "    Once the oil is heated, add cumin seeds, green chillies, curry leaves and garlic paste\n" +
            "    Fry till the leaves have turned crispy and rest have the spices are cooked\n \n" +
            "    Once cooked, keep them aside for garnishing\n" +
            "    To the same pan, add the seasoning that was earlier prepared in step 3\n" +
            "    Once the seasoning starts to bubble, add the fried chicken pieces to it and toss & fry on medium heat\n" +
            "    Fry the chicken till the time all the moisture has vanished and the chicken has become slightly crisp\n" +
            "    Switch off the heat and take the chicken out in a serving dish\n" +
            "    Garnish with chopped spring onions and serve hot!\n" +
            "    Try some of the other products from Dabur Hommade & prepare delicious recipes:\n" +
            "    Ginger Paste\n" +
            "    Tamarind Paste\n" +
            "    Tomato Puree\n" +
            "    Coconut Milk\n","INGREDIENTS     250 gms white fish (cut into cubes)\n" +
            "    1 medium onion\n" +
            "    1 medium tomato\n" +
            "    6-8 garlic cloves\n" +
            "    2 fresh green chillies (deseeded), sliced\n" +
            "    6 tbsp oil\n" +
            "    1/2 cup fresh coconut paste\n" +
            "    1/4 tsp red chilli paste\n" +
            "    1 tsp coriander powder\n" +
            "    1/2 tsp turmeric powder\n" +
            "    1 tsp salt\n" +
            "    2 Whole dry red chillies\n" +
            "    1/2 tsp black mustard seeds\n" +
            "    8-10 Curry leaves\n" +
            "    1/2 cup tamarind extract\n" +
            "    1 cup water How to Make Kerala Fish Curry\n" +
            "\n" +
            "    1.\n" +
            "    Make a paste of onion, tomatoes, garlic and green chillies. Keep aside.\n" +
            "    2.\n" +
            "    Heat oil in a pan.\n" +
            "    3.\n" +
            "    Add coconut paste and cook until golden brown.\n" +
            "    4.\n" +
            "    Add dry spices and cook for about 3 minutes, keep stirring.\n" +
            "    5.\n" +
            "    Remove from heat and keep aside.\n" +
            "    6.\n" +
            "    Heat the remaining oil in another saucepan.\n" +
            "    7.\n" +
            "    Add whole red chillies, curry leaves and mustard seeds.\n" +
            "    8.\n" +
            "    Fry until the seeds start spluttering.\n" +
            "    9.\n" +
            "    Add onion paste and fry until brown.\n" +
            "    10.\n" +
            "    Add the cooked coconut paste, tamarind extract and a cup of water.\n" +
            "    11.\n" +
            "    Stir well and bring to a boil.\n" +
            "    12.\n" +
            "    Add fish pieces and simmer for about 10 minutes.\n" +
            "    13.\n" +
            "    Serve hot with boiled rice.","\n" +
            "Ingredients\n" +
            "For the marinade\n" +
            "\n" +
            "    ½ kg fish (see notes, I have used pompano here)\n" +
            "    1 tbsp lemon juice\n" +
            "    1 tsp turmeric powder\n" +
            "    1 tsp pepper powder\n" +
            "    Salt (as required)\n" +
            "\n" +
            "For the fish molee\n" +
            "\n" +
            "    ½ inch sized ginger piece (finely minced)\n" +
            "    2 garlic cloves (finely chopped)\n" +
            "    1 medium sized onion (sliced)\n" +
            "    3-4 green chilies (slit)\n" +
            "    ¼ tsp turmeric powder\n" +
            "    1 tsp pepper\n" +
            "    1 cup thin coconut milk\n" +
            "    1 cup thick coconut milk\n" +
            "    2 sprigs of curry leaves\n" +
            "    1 tbsp lemon juice\n" +
            "    1 to mato (sliced to rounds)\n" +
            "    Salt (as required)\n" +
            "    Coconut oil (as required)\n" +
            "\n HOW TO MAKE IT \n" +
            "\n" +
            "    Clean and cut fish into pieces. Marinate with lemon juice, pepper, salt and turmeric powder for 15-20 minutes.\n" +
            "    In a kadai/pan, add little oil and shallow fry fish on both sides. Keep it aside.\n" +
            "    In a separate pan, add oil and heat on a medium flame. Add curry leaves, sliced ginger, garlic and green chilies, sauté for a minute until its raw smell subsides.\n" +
            "    Add the sliced onions and sauté until it turns translucent, ensure not to brown the onions.\n" +
            "    Follow by adding turmeric powder, pepper powder and thin coconut milk. Close the lid and allow the curry to boil for 5-6 minutes on a medium flame. When the oil starts separating, reduce the flame to a low and add lemon juice, mix well.\n" +
            "    Now add the fried fish, cover it with the gravy, and allow the curry to blend well with the fish, bring to a boil. Do not stir once the fish is added, instead rotate the pan to mix the gravy.\n" +
            "    Add the thick coconut milk and cook on a low flame for another 2 minutes, make sure not to allow the dish to boil beyond this stage. Check for the seasoning.\n" +
            "    Add sliced round tomatoes and more curry leaves, close the lid and switch off the flame. Let the tomato cook in the remaining steam.\n" +
            "    Serve with Appam, Idiyappam, Chapati/Roti, Rice or Bread.\n" +
            "\n","Ingredients of Chilli Chicken\n" +
            "\n" +
            "    400 gms boneless chicken\n" +
            "    1 1/2 tbsp salt\n" +
            "    4 tsp cornflour\n" +
            "    2 tsp black pepper\n" +
            "    1 egg\n" +
            "    3 tsp soy sauce\n" +
            "    3 tsp red chilli sauce\n" +
            "    8-10 garlic, chopped\n" +
            "    8-10 green chillies\n" +
            "    2 tsp green chilli sauce\n" +
            "    1 tsp vinegar\n" +
            "    1 onion, chopped\n" +
            "    1 capsicum, chopped\n" +
            "    1 tsp black Pepper\n" +
            "    1 tsp salt HOW TO MAKE IT 1.\n" +
            "Take the chicken in a bowl, add salt, cornflour, black pepper, egg, soy sauce and red chilli sauce. After the marination, take out the chicken pieces and deep fry in a pan.Chilli Chicken\n" +
            "4.\n" +
            "Deep fry the chicken until golden brown.Chilli Chicken\n" +
            "5.\n" +
            "Now, in another pan put chopped garlic and green chillies. Stir them well.Chilli Chicken\n" +
            "6.\n" +
            "Add the fried chicken to the pan, followed by soy sauce, green chilli sauce, vinegar, onion, capsicum, black pepper and salt.Chilli Chicken\n" +
            "7.\n" +
            "Mix all of these together.Chilli Chicken\n" +
            "8.\n" +
            "Serve hot.Chilli Chicken","Ingredients\n" +
            "For Marinating:\n" +
            "\n" +
            "    Beef (Buffalo meat) – ½ kg\n" +
            "    Turmeric powder- ½ tsp\n" +
            "    Chilly powder-1 tsp\n" +
            "    Coriander Powder-2 tsp\n" +
            "    Pepper Powder-1 tsp\n" +
            "    Lemon Juice- 1 Lemon's\n" +
            "    Salt- 1 ½ tsp or required\n" +
            "    Ginger Garlic paste-2 tsp\n" +
            "\n" +
            "For Roasting:\n" +
            "\n" +
            "    Onions-2 sliced\n" +
            "    Shallots- 1 handful (cut each one into 2 pieces)\n" +
            "    Fennel Seeds (Perum Jeerakam) - ½ tsp\n" +
            "    Tomato-1 sliced\n" +
            "    Green chilly- 2 0r 3\n" +
            "    Ginger Garlic paste- 2 tsp\n" +
            "    Turmeric powder- ½ tsp\n" +
            "    Chilly Powder-1 tsp\n" +
            "    Coriander powder- 3 tsp\n" +
            "    Garam Masala- 1 ½ tsp\n" +
            "    Curry Leaves- few\n" +
            "    Coconut tidbits (Coconut cuts) - as required\n" +
            "    Coconut Oil- as required\n" +
            "    Salt- ½ tsp or as required\n HOW TO MAKE IT \n" +
            "    Cut the beef into small pieces and wash it thoroughly. Prepare all other ingredients.\n" +
            "    Marinate the pieces of beef with other ingredients for marinating about 1 or 2 hours.\n" +
            "    Pressure cook the marinated beef with 2 cups of water about 20 to 30 minutes or according to the meat on medium-low flame.\n" +
            "    Heat coconut oil in a pan and splutter fennel seeds. (You can add more fresh garlic after this step for more taste).\n" +
            "    Add sliced onions, shallots, green chilly and curry leaves. Saute well. Sprinkle some salt to saute it quickly.\n" +
            "    Add sliced tomato. Stir until onion turns brown.\n" +
            "    Add ginger garlic paste.\n" +
            "    Add Coconut tidbits and saute it for some time (You can prefer to add coconut tidbits after spluttering fennel seeds).\n" +
            "    Add chilly powder, turmeric powder, coriander powder and garam masala. The raw smell will fade eventually.\n" +
            "    Add cooked meat with juices and mix well. Cook on low flame and stir occasionally to prevent it from sticking to the pan.\n" +
            "    Add Curry leaves and slow roast until beef becomes dry and dark brown in colour. Serve with rice or tapioca or anything you like.\n","Ingredients\n" +
            "\n" +
            "    350g thin-cut minute steak\n" +
            "    Steak\n" +
            "\n" +
            "    , very thinly sliced into strips\n" +
            "    3 tbsp cornflour\n" +
            "    2 tsp Chinese five-spice powder\n" +
            "    100ml vegetable oil\n" +
            "    1 red pepper, thinly sliced\n" +
            "    1 red chilli, thinly sliced\n" +
            "    4 spring onions\n" +
            "    Spring onions\n" +
            "\n" +
            "    , sliced, green and white parts separated\n" +
            "    2 garlic cloves, crushed\n" +
            "    thumb-sized piece ginger\n" +
            "    Ginger\n" +
            "\n" +
            "    , cut into matchsticks\n" +
            "    4 tbsp rice wine vinegar or white wine vinegar\n" +
            "    1 tbsp soy sauce\n" +
            "    Soy sauce\n" +
            "\n" +
            "    2 tbsp sweet chilli sauce\n" +
            "    2 tbsp tomato ketchup\n" +
            "    cooked noodles, to serve (optional)\n" +
            "    prawn\n" +
            "    Prawn\n" +
            "\n" +
            "    crackers, to serve (optional)  HOW TO MAKE IT     Put 350g thin-cut minute steak strips in a bowl and toss in 3 tbsp cornflour and 2 tsp Chinese five-spice powder.\n" +
            "\n" +
            "    Heat 100ml vegetable oil in a wok or large frying pan until hot, then add the beef and fry until golden and crisp.\n" +
            "\n" +
            "    Scoop out the beef and drain on kitchen paper. Pour away all but 1 tbsp oil.\n" +
            "\n" +
            "    Add 1 thinly sliced red pepper, ½ thinly sliced red chilli, sliced white ends of 4 spring onions, 2 crushed garlic cloves and thumb-sized piece ginger, cut into matchsticks, to the pan. Stir-fry for 3 mins to soften, but don’t let the garlic and ginger burn.\n" +
            "\n" +
            "    Mix the 4 tbsp rice wine vinegar or white wine vinegar, 1 tbsp soy sauce, 2 tbsp sweet chilli sauce and 2 tbsp tomato ketchup in a jug with 2 tbsp water, then pour over the veg.\n" +
            "\n" +
            "    Bubble for 2 mins, then add the beef back to the pan and toss well to coat.\n" +
            "\n" +
            "    Serve the beef on noodles with prawn crackers, if you like, scattered with the remaining ½ sliced red chilli and sliced green parts of the spring onions.","\n" +
            "Ingredients\n" +
            "\n" +
            "    1/2 kg - Mutton chops\n" +
            "    2 tbsp - ginger- Garlic paste\n" +
            "    3 -onions\n" +
            "    4 - Tomatoes\n" +
            "    3 tsp - Red Chilli powder\n" +
            "    1.5 tsp - coriander powder\n" +
            "    2 tsp - Garam Masala powder\n" +
            "    2 tsp - chaat masala\n" +
            "    Oil\n" +
            "    Salt\n" +
            "    Cooking soda - 1 small pinch\n" +
            "\n \n" +
            "How to Make Easy Mutton Chops\n" +
            "\n" +
            "    Grind the onion and tomato coarsely.\n" +
            "    Heat oil in a pressure cooker and add ginger garlic paste. Saute well.\n" +
            "    Add the ground tomato and onion, and saute for a while.\n" +
            "    Add salt, mutton chops and fry for 2-3 minutes. Then add chilli, coriander powder, a pinch of cooking soda and 2 cups of hot water.\n" +
            "    Close and pressure cook for 15 mins till the mutton cooks.\n" +
            "    Let cool and open. The simmer uncovered until the gravy thickens.\n" +
            "    Add chat masala and garam masala cook till the gravy reduces to a thicker consistency - almost dry.\n" +
            "    Sprinkle coriander leaves before serving.\n" +
            "\n"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menun);
        t1=(TextView)findViewById(R.id.t1);
        i1=(ImageView)findViewById(R.id.i1);
        t2=(TextView)findViewById(R.id.t2);
        b1=(Button)findViewById(R.id.b1);
        w1=(WebView)findViewById(R.id.w1);
        Intent in=getIntent();
        int i=in.getIntExtra("pos",0);
        String s=in.getStringExtra("name");
        t1.setText(s);
        i1.setImageResource(img[i]);
        t2.setText(d[i]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent in=new Intent(menuv.this,Menuvu.class);
                // m=new MediaController(getApplicationContext());
                // startActivity(in);

                w1.loadUrl("https://www.youtube.com");
            }
        });

    }
}
