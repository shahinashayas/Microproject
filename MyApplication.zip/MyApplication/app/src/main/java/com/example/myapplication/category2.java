package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class category2 extends AppCompatActivity {
    ListView l2;
    String str[]={"CHICKEN CURRY","BIEF CURRY","MUTTON CURRY","CHIKEN 65","FISH CURRY","FISH MOLLY","CHILLY CHICKEN","BIEF ROAST","BIEF CHILLY","MUTTON CHAPS"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category2);
        l2=(ListView)findViewById(R.id.l2);
        ArrayAdapter<String> ads=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,str);
        l2.setAdapter(ads);
        l2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {



                Intent in=new Intent(category2.this,menun.class);
                in.putExtra("pos",position);
                in.putExtra("name",str[position]);
                startActivity(in);

            }
        });

    }
}
