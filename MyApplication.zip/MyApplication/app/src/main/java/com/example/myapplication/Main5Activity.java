package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main5Activity extends AppCompatActivity {
    EditText e1,e2;
    Button b1,b2;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        e1=(EditText)findViewById(R.id.e1);
        e2=(EditText)findViewById(R.id.e2);
        b1=(Button)findViewById(R.id.b1);
        b2=(Button)findViewById(R.id.b2);
        db=openOrCreateDatabase("kitchenDB", Context.MODE_PRIVATE,null);
        if (db !=null){
            Toast.makeText(this,"created",Toast.LENGTH_SHORT).show();
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS kitchen (name VARCHAR,des VARCHAR) ");
        b1.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (e1.getText().toString().trim().length()==0||e2.getText().toString().trim().length()==0){
                    ShowMessage("Error","Please enter all values");
                    return;
                }
                db.execSQL("INSERT INTO kitchen VALUES('"+e1.getText()+"','"+e2.getText()+"');");
                ShowMessage("Success","Record added");
                clearText();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c=db.rawQuery("SELECT * FROM kitchen",null);
                if (c.getCount()==0){
                    ShowMessage("Error","ne records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while (c.moveToNext()){
                    buffer.append("name:"+c.getString(0)+"\n");
                    buffer.append("des:"+c.getString(1)+"\n");
                }
                ShowMessage("kitchen details",buffer.toString());
            }
        });

    }


    public void ShowMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText(){
        e1.setText("");
        e2.setText("");
        e1.requestFocus();
    }
}
