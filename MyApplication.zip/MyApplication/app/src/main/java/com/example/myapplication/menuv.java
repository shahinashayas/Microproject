package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class menuv extends AppCompatActivity {
    TextView t1,t2,t3;
    ImageView i1;
    Button b1;
    WebView w1;
    Integer pos;
    Integer img[]={R.drawable.sam,R.drawable.aviyal,R.drawable.pachadi,R.drawable.erisherry,R.drawable.pulisherry,R.drawable.kichdi,R.drawable.olan,R.drawable.kalan,R.drawable.rasam,R.drawable.inchi};
    String d[] = {"Ingredients for sambar recipe\n" +
            "\n" +
            "    ¾ cup Toor dal (or split pigeon peas) (refer notes)\n" + "    1 to 2 tbsp Tamarind or tamarind paste as needed\n" + "    ¼ cup Coriander leaves few with tender stalks – chopped\n" +
            "    salt as needed\n" + " 1/8 tsp turmeric (skip if your sambar powder has it).Vegetables for sambar\n" + "\n" + "    12 to 15 shallots (or small onions) or 1 medium onion sliced, refer notes\n" +
            "    1 to 2 vegetable drumsticks (or moringa)\n" +
            "    2 to 3 Ladies finger (or okra, bhindi)\n" +
            "    3 to 4 cubed red pumpkin pieces (optional)\n" +
            "    1 green chili slit (optional)\n" +
            "    1 medium tomato chopped." +
            "Preparation for sambar recipe\n" +
            "\n" +
            "    Wash toor dal a few times in cooker or pot until the water runs clear.\n" +
            "\n" +
            "    Pour 2 cups water & pressure cook on a medium heat for 2 to 4 whistles depending on the brand of cooker. The dal needs to be cooked till smooth. It can even be cooked in a pot.\n" +
            "\n" +
            "    Wash all the veggies. Scrape the drumsticks lightly & rinse. Chop them to 2 inch pieces. Peel the shallots as well & rinse. Chop tomatoes & okra to 1 inch pieces. If using pumpkin peel the skin & dice them. Set aside." ,"Ingredients: \n" +
            "\n" +
            "Mixed Vegetables ( Raw Plantain, Elephant Yam, Yellow Cucumber, Carrot, Potato, Drumstick, Chayote Squash), cut into 3 inch long strips (peel the plantain, yam, cucumber, potato) – 2 cups\n" +
            "Water – about 2 to 3 cups, just enough to cook the vegetables\n" +
            "Turmeric powder – 1/2 tsp\n" +
            "Salt – to taste\n" +
            "\n" +
            "To grind to a paste:\n" +
            "Grated coconut (frozen will do) – 1/2 cup\n" +
            "Yogurt – 1/4 cup\n" +
            "Cumin seeds – 1/2 tsp\n" +
            "Green Thai chillies – 2 or 3\n" +
            "\n" +
            "For garnish:\n" +
            "Curry leaves – 10\n" +
            "Coconut Oil – 2 tsp\n" +
            "\n" +
            "Method:\n" +
            "\n" +
            "Cook the vegetables in the water with the turmeric powder, till soft. Check the drumstick to see if it is soft, if so all other vegetables should be cooked. Drumstick takes the longest to cook. Add salt to this once the vegetables are cooked.\n" +
            "Grind together the coconut, cumin, green chillies and yogurt to a fine paste.\n" +
            "Add this paste to the cooked vegetables.\n" +
            "Garnish/season with the coconut oil and curry leaves.","Ingredients\n" +
            "\n" +
            "    2 cups Kani Vellarikka / Golden Cucumber cubed (measured after cutting)\n" +
            "    2 Small onion / shallots / Pearl Onion sliced\n" +
            "    1-2 Green chilli slit lengthwise\n" +
            "    1 tsp Chopped ginger\n" +
            "    1/2 cup Grated coconut\n" +
            "    1/4 tsp Chopped garlic\n" +
            "    A pinch Jeera / Cumin\n" +
            "    1/4 tsp Crushed mustard seeds\n" +
            "    500 gms Yogurt @ room temp\n" +
            "    Salt\n" +
            "    Coconut oil\n" +
            "    Curry leaves\n" +
            "\n" +
            "Instructions\n" +
            "\n" +
            "    Grind together coconut, chopped garlic and jeera with 2-3 tbsp water to a smooth paste. Whisk the yogurt and keep aside.\n" +
            "    Heat oil in a pan and add cubed cucumber, sliced small onion,green chilli, ginger, curry leaves and salt. Stir it for 2 mins. Add 1/2 - 3/4 cup water. Cook till the cucumber becomes soft. Add crushed mustard to this. Mix well.\n" +
            "    Add coconut paste, cook for 3-4 mins till the raw taste of coconut changes. Remove from fire and add whisked yogurt. Combine well.\n" +
            "    Bring back to fire and keep stirring for 3-5 mins. Do not let it boil. Drizzle some coconut oil and remove from fire.\n" +
            "    The dish has a medium thick consistency.","Ingredients :\n" +
            "\n" +
            "    Yellow Pumpkin /Mathanga : 1 cup (diced)\n" +
            "    Red oriental beans/Van payar : ½ cup\n" +
            "    Turmeric powder /Manjal podi : ¼ tsp\n" +
            "    Salt to taste\n" +
            "    To Grind :\n" +
            "    Small Onion /Shallots : 1-2 (optional)\n" +
            "    Green Chillies : 3-4\n" +
            "    Grated Coconut : ½ cup\n" +
            "    Cumin Seeds : ½ tsp\n" +
            "    For Tempering :\n" +
            "    Dry Red Chillies : 2 nos\n" +
            "    Grated Coconut : 4 tbsp\n" +
            "    Curry leaves : 1 sprig\n" +
            "    Mustard seeds : 1 tsp\n" +
            "    Coconut Oil : 2 tsp How to Make :\n" +
            "\n" +
            "    Soak red beans overnight; pressure cook the beans with enough water, red chilly powder, turmeric powder and salt for 4-5 whistle. After the pressure settles open the cooker.\n" +
            "    Add the pumpkin piece and cook uncovered till the pumpkin turns to soft and tender; when the pumpkin and beans is cooked slightly mash the pumpkin pieces.\n" +
            "    Grind grated coconut, cumin seeds, green chillies and small onions with little water to coarsed smooth paste (Note : The paste should not be watery, it should be in chutney consistency.)\n" +
            "    Add this ground coconut paste and mix thoroughly with pumpkin and red beans.\n" +
            "    Heat a tsp of oil in a pan , add mustard seeds when its starts to splutter, add dry red chillies, grated coconut and curry leaves and fry till they turn golden brown. (Note : Be sure not to burn it)\n" +
            "    Pour this tempering and drizzle ½ tsp of coconut oil over the gravy, mix well and adjust the salt.\n" +
            "    Serve with hot Kerala Red Rice and papadam. Enjoy!\n" ,"Ingredients of Pulissery\n" +
            "\n" +
            "    1 Cup Buttermilk or curd\n" +
            "    1 Cup Ash gourd (sliced) or cucumber (chopped)\n" +
            "    2 Garlic pods\n" +
            "    2 Shallots (small onions)\n" +
            "    1/2 tsp Turmeric\n" +
            "    1/2 Cup Coconut, grated\n" +
            "    1/2 tsp Cumin seeds\n" +
            "    2 Green chiili\n" +
            "    1/4 tsp Red chilli powder\n" +
            "    2 Red chillies\n" +
            "    1/4 tsp Fenugreek\n" +
            "    1/2 tsp Mustard\n" +
            "    2 Curry leaves\n" +
            "    2 tsp Coconut oil\n" +
            "    1 Cup Water\n" +
            "    As required Salt How to Make Pulissery\n" +
            "\n" +
            "    1.\n" +
            "    Blend grated coconut along with garlic, shallots (small onions), cumin seeds and green chillies into a fine paste. Keep it aside.\n" +
            "    2.\n" +
            "    Take a pan and add sliced ash gourd or cucumber pieces in 3/4 cup of water. Since ash gourd cooking time is fast, make sure the pieces are not overcooked. To ensure this, cook it over a low flame.\n" +
            "    3.\n" +
            "    Once the ash gourd is cooked well, add the grated coconut paste and curd to the mix. Leave it to simmer in a low flame. Turn off the stove when the curry is just brought to a boil. Make sure the curd doesn't boil more than a minute or two.\n" +
            "    For the tempering:\n" +
            "    1.\n" +
            "    Heat the coconut oil in a pan and add mustard seeds and fenugreek seeds. Just when they start spluttering, add red chillies and curry leaves. Finally, add turmeric powder and salt.\n" +
            "    2.\n" +
            "    Saute until it turns golden brown. For more spicy touch, add red chilli powder. Now finally add this mix to the prepared pulissery. Stir it well.\n" +
            "    3.\n" +
            "    It is best served with hot rice.","\n" +
            "Ingredients\n" +
            "\n" +
            "    1/2 cup small grain Rice\n" +
            "    1/4 cup Arhar Dal (Toor dal/ Split Pigeon Peas)\n" +
            "    1/4 cup dhuli Moong Dal (skinless Petite Yellow Lentils)\n" +
            "    2 tablespoons Ghee\n" +
            "    1 teaspoon Cumin Seeds\n" +
            "    6-8 whole Peppercorns\n" +
            "    2 Bayleaves\n" +
            "    4-5 Cloves\n" +
            "    2 whole Cardamoms\n" +
            "    1 teaspoon grated Ginger\n" +
            "    1 Green Chilli or Serrano Chilli, split lengthwise\n" +
            "    6-8 Cauliflower Florets\n" +
            "    1 Potato, quartered\n" +
            "    1 large Carrot, peeled and cut into 1 inch pieces\n" +
            "    8-10 French Beans, cut into 1 inch pieces\n" +
            "    1/2 cup frozen or fresh Green Peas\n" +
            "    1 teaspoon Turmeric\n" +
            "    1/2 teaspoon Red Chilli Powder or Paprika Powder\n" +
            "    1.5 teaspoons Salt\n" +
            "    5 cups Water\n" +
            "\n HOW TO MAKE IT \n" +
            "    Wash the rice and both the dals (lentils) well, and soak them in enough water to cover them for at least 30 minutes or up to two hours. This helps them cook faster.\n" +
            "    Heat ghee in the pressure cooker and add cumin seeds, peppercorns, bayleaves, cloves, cardamoms, ginger and green chilli. Saute for two minutes on medium flame.\n" +
            "    Drain all the water from the rice and lentils and add them to the cooker. Dry roast them for 4-5 minutes, till you can smell a nutty aroma. Don’t worry if some of the rice and lentils stick to the bottom of the pan, but be careful not to burn them.\n" +
            "    Add all the veggies, turmeric, chilli powder, salt and water to the cooker and pressure cook for 6-7 whistles. Let the pressure release naturally. Once all the pressure has released, open the pressure cooker and mix well. After mixing, the rice and dal should have broken down and should look slightly creamy. Check for salt, and serve hot with ghee, fried potatoes, tomato chutney or just yogurt.\n","INGREDIENTS     1 cup thinly sliced watermelon\n" +
            "    4 sliced green chilli\n" +
            "    3/4 cup Coconut milk\n" +
            "    2 teaspoon coconut oil\n" +
            "\n" +
            "    1 cup thinly sliced pumpkin\n" +
            "    3 tablespoon black eyed beans\n" +
            "    1/2 teaspoon salt How to make Olan\n" +
            "\n" +
            "    Step 1\n" +
            "\n" +
            "    Cook the beans in a pressure cooker in enough water till tender,drain and keep aside.\n" +
            "    Step 2\n" +
            "\n" +
            "    Steam the ash gourd,pumpkins and green chillies, till they are soft.\n" +
            "    Step 3\n" +
            "\n" +
            "    Mix in the cooked beans and salt to taste, add a little water, and when the mix starts to boil, add the coconut milk.\n" +
            "    Step 4\n" +
            "\n" +
            "    Turn off the flame, heat the coconut oil in a pan, put some fenugreek seeds, whole red chillies, mustard seeds, and crushed curry leaves.\n" +
            "    Step 5\n" +
            "\n" +
            "    When the mustard starts to sputter, turn the lot over the cooked - olan, close with a lit and let flavours blend for 10 minutes.","Ingredients of Kalan Kerala Curry\n" +
            "\n" +
            "    3 Cups Butter milk (thick)\n" +
            "    2 Cups Yam and raw bananas (cut into thin slices)\n" +
            "    1 tsp Turmeric powder\n" +
            "    1 tsp Fenugreek seeds, powdered\n" +
            "    1 tsp Black pepper powder\n" +
            "    1/2 Cup Coconut (grind with 2 green chilies), grated\n" +
            "    To taste Salt\n" +
            "    1 Tbsp Coconut oil\n" +
            "    1/4 tsp Mustard seeds\n" +
            "    Few Curry leaves How to Make Kalan Kerala Curry\n" +
            "\n" +
            "    1.\n" +
            "    Cook yam and bananas in butter milk with turmeric powder till they get soft.\n" +
            "    2.\n" +
            "    Add salt, grated paste of coconut to it and cook for few minutes.\n" +
            "    3.\n" +
            "    Heat the coconut oil. Add mustard seeds and curry leaves to it and stir for a few minutes.\n" +
            "    4.\n" +
            "    Add the buttermilk mixture to this along with the black pepper and fenugreek seeds. Mix well.\n" +
            "    5.\n" +
            "    The dish is ready to serve. Garnish with mustard seeds and curry leaves.","INGREDIENTS     3 chopped tomato\n" +
            "    1/2 teaspoon cumin seeds\n" +
            "    1/2 piece ginger\n" +
            "    1 handful chopped coriander leaves\n" +
            "    2 cup water\n" +
            "\n" +
            "    1 pinch asafoetida\n" +
            "    1 teaspoon peppercorns\n" +
            "    5 curry leaves\n" +
            "    salt as required How to make Rasam\n" +
            "\n" +
            "    tomatoes\n" +
            "    Step 1\n" +
            "\n" +
            "    Soak the tomatoes and ginger in lukewarm water with a pinch of salt and this will remove the adulterant from the tomatoes. Then, take a grinder and add tomatoes, asafoetida, cumin seeds, peppercorns, ginger, curry leaves, coriander leaves and salt in it. Grind all these ingredients to a paste.\n" +
            "    red-gravy\n" +
            "    Step 2\n" +
            "\n" +
            "    Now, take a pan and add 2 cups of water in it. Heat the pan over medium flame. Add the ground paste and bring to a boil. Stir it for 1-2 minutes and then switch off the flame. Remove and keep it aside.\n" +
            "    rasam\n" +
            "    Step 3\n" +
            "\n" +
            "    For the tempering, heat ghee in a pan over medium flame. Add mustard seeds in the same pan and allow them to fry. Fry the mustard seeds for 20 seconds and pour into the rasam. To make it more delicious add some curry leaves and green chillies. Fry this mix until it starts crackling. Transfer the rasam in serving bowls and pair them with crispy papads and platter of chutneys.","INGREDIENTS 1. Ginger – 1 cup, roughly chopped\n" +
            "\n" +
            "2. Coconut oil – 3 tbsp\n" +
            "\n" +
            "3. Mustard seeds – 1/2 tsp\n" +
            "\n" +
            "    Dried red chilies – 2\n" +
            "\n" +
            "4. Pearl onions – 12, thinly sliced\n" +
            "\n" +
            "    Curry leaves – 1 sprig\n" +
            "\n" +
            "    Green chilies – 2, finely chopped\n" +
            "\n" +
            "5. Turmeric powder – 1/2 tsp\n" +
            "\n" +
            "     Kashmiri chilli powder – 1 tsp\n" +
            "\n" +
            "6. Tamarind juice – Small goose-berry sized (Soaked in 1/2 cup hot water and squeezed)\n" +
            "\n" +
            "7. Jaggery – 1/2 tsp or to taste\n" +
            "\n" +
            "8. Salt – To taste\n" +
            "\n" +
            "To roast and grind\n" +
            "\n" +
            "9. Grated coconut – 1 cup\n" +
            "\n" +
            "    Coriander powder – 2 tsp\n" +
            "\n" +
            "    Kashmiri chilli powder – 1 tsp\n" +
            "\n" +
            "    Fenugreek powder – 1/4 tsp Method\n" +
            "\n" +
            "1. Dry roast grated coconut until browned (take care not to burn it). Bring down the heat to low. Add turmeric powder, chilly powder and fenugreek powder. Stir for 30 seconds and switch off. Grind to a fine paste and set aside.\n" +
            "\n" +
            "2. Peel and finely chop ginger. (OR roughly chop ginger and pulse in the small jar of a mixie until coarsely ground).\n" +
            "\n" +
            "3. Heat coconut oil in a cheena chatti at medium-high heat. Splutter mustard seeds and fry dried red chilies until brown. Add finely chopped ginger, sliced pearl onions, curry leaves and green chilies. Saute until they get lightly browned and the raw taste of ginger is gone. (If the ginger sticks to the kadai while sauteing, sprinkle little water. You can use a non-stick pan to avoid them from sticking).\n" +
            "\n" +
            "4. Add turmeric powder, chilly powder and mix well. Next add ground roasted coconut paste, jaggery, enough salt and 1.5 – 2 cup hot water. Bring to a boil and cook for 6 – 8 minutes until oil separates and it gets thickened. Add few curry leaves and switch off. Serve with rice and other side-dishes.  "};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menuv);
        t1=(TextView)findViewById(R.id.t1);
        i1=(ImageView)findViewById(R.id.i1);
        t2=(TextView)findViewById(R.id.t2);
        b1=(Button)findViewById(R.id.b1);
        w1=(WebView)findViewById(R.id.w1);
        Intent in=getIntent();
        int i=in.getIntExtra("pos",0);
        String s=in.getStringExtra("name");
        t1.setText(s);
        i1.setImageResource(img[i]);
        t2.setText(d[i]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent in=new Intent(menuv.this,Menuvu.class);
               // m=new MediaController(getApplicationContext());
               // startActivity(in);

                w1.loadUrl("https://www.youtube.com");
            }
        });

    }
}
